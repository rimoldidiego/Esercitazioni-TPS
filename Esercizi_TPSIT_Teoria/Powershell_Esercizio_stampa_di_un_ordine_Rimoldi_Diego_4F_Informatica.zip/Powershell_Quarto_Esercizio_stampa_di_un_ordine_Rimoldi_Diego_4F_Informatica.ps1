﻿Write-Host "Inserisci il nome dell'utente"

$nomeUtente = Read-Host

Write-Host "Inserisci il primo prodotto"

$p1 = Read-Host

Write-Host "Inserisci il costo del primo prodotto"

[int]$cp1 = Read-Host

Write-Host "Inserisci il secondo prodotto"

$p2 = Read-Host

Write-Host "Inserisci il costo del secondo prodotto"

[int]$cp2 = Read-Host

Write-Host "Inserisci il terzo prodotto"

$p3 = Read-Host

Write-Host "Inserisci il costo del terzo prodotto"

[int]$cp3 = Read-Host

$cTotParz = $cp1 + $cp1 + $cp3

$sEuro = [char][int]0x20ac

$b = 20

$m = "Non hai diritto a ricevere il bonus"

$cTot

Write-Host " "

Write-Host "L'ordine effettuato da $nomeUtente, comprende: "

Write-Host " "

Write-Host "-$p1 costo: $cp1 $sEuro,"

Write-Host "-$p2 costo: $cp2 $sEuro,"

Write-Host "-$p3 costo: $cp3 $sEuro."

Write-Host " "

Write-Host "Il costo totale degli ordini effettuati senza l'ausilio del bonus è di: $cTotParz $sEuro"

if($cTotParz % 2 -eq 0)
    
    {

    $cTot = $cTotParz + $b
     
    Write-Host "Il costo totale degli ordini effettuati con l'ausilio del bonus è di: $cTotParz $sEuro"
    
    }
else
    {Write-Host $m}
