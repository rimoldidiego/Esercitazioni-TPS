
param(
	[parameter(Mandatory=$true)][string]$nome,
	[parameter(Mandatory=$true)][string]$cognome,
	[parameter(Mandatory=$false)][int]$numero1,
	[parameter(Mandatory=$false)][string]$gucci,
	[parameter(Mandatory=$false)][int]$numero2,
	[parameter(Mandatory=$false)][string]$fendi,
	[parameter(Mandatory=$false)][int]$numero3,
	[parameter(Mandatory=$false)][string]$nike
)

write-host "L'ordine di $nome $cognome comprende: $numero1 $gucci, $numero2 $fendi, $numero3 $nike"