##########################################################################################################################################################



#Creazione Elenco di tutti i servizi disponibili e conversione in una tabella HTML con le colonne: Nome, Stato e Tipo di avvio:


Get-Service | Select-Object Name, Status, StartType | ConvertTo-Html | Out-File Stampa_Quinto_Esercizio_Powershell_Rimoldi_Diego_4F_Informatica.html



##########################################################################################################################################################