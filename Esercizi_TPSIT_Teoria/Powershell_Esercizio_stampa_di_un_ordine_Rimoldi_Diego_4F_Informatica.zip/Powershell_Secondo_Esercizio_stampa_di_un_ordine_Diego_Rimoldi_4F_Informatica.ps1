
$args[0]
$args[1]
$args[2]
$args[3]
$args[4]
$args[5]

$ordine="L'ordine è stato effettuato da: " + $args[0] + " " + $args[1] + " e comprende: " + $args[2] + " " + $args[3] + " " + $args[4] + " " + $args[5] 

write-host $ordine