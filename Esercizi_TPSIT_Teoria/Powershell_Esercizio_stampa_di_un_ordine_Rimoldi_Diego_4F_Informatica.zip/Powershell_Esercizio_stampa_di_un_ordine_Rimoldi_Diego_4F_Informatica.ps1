###########################

#Creazione Variabili

$nome = "Rimoldi Diego"
$numero1 = 5
$scarpe = "Scarpe Puma"
$numero2 = 7
$maglie = "Magliette Adidas"
$numero3 = 3
$felpe = "Felpe Champions"
$numeropezzi = $numero1 + $numero2 + $numero3
$spedizione = "BRT"
$dataodierna = Get-Date
$dataspedizione = $dataodierna.AddDays(7)

#Unione di stringhe

$unionestringhe ="Ciao $nome il tuo ordine, comprende: $numero1 paia di $scarpe, $numero2 $maglie, $numero3 $felpe. Per un totale di $numeropezzi pezzi recapitati per la spedizione al corriere: $spedizione. Gli articoli giungeranno a destinazione in data: $dataspedizione."

#Stampa delle variabili

Write-Output $unionestringhe

###########################